// ================================
// PHOTO MEMORIES
// Make sure these filenames match
// the files inside your Photos folder.
// ================================

const memories = [
    {
        image: "Photos/photo1 (1).jpg",
        title: "The Beginning",
        message: "Every beautiful story has a beginning. I'm glad ours started."
    },
    {
        image: "Photos/photo2.jpg",
        title: "Your Smile",
        message: "Your smile is still one of my favorite things."
    },
    {
        image: "Photos/photo3.jpg",
        title: "Our Little Moments",
        message: "Even the simplest moments become special with you."
    },
    {
        image: "Photos/photo4.jpg",
        title: "My Favorite Person",
        message: "Out of everyone, I'm grateful I get to share these moments with you."
    },
    {
        image: "Photos/photo5.jpg",
        title: "The Memories",
        message: "I wish I could pause time whenever I'm with you."
    },
    {
        image: "Photos/photo6.jpg",
        title: "Through Everything",
        message: "Thank you for staying and making memories with me."
    },
    {
        image: "Photos/photo7.jpg",
        title: "A Little More Love",
        message: "Every day gives me another reason to appreciate you."
    },
    {
        image: "Photos/photo8.jpg",
        title: "Us",
        message: "It's not about having perfect days. It's about having you beside me."
    },
    {
        image: "Photos/photo9.jpg",
        title: "Two Months",
        message: "Two months of memories, laughter, and moments I'll always treasure."
    },
    {
        image: "Photos/photo10.jpg",
        title: "And Many More",
        message: "I look forward to making many more memories with you."
    }
];

// ================================
// SETTINGS
// ================================

const PHOTO_DURATION = 5000; // 5 seconds per photo
const QUIET_MUSIC_VOLUME = 0.15;

// ================================
// HTML ELEMENTS
// These IDs match your index.html
// ================================

const welcomeScreen = document.getElementById("welcomeScreen");
const slideshowScreen = document.getElementById("slideshowScreen");
const voiceScreen = document.getElementById("voiceScreen");
const finalScreen = document.getElementById("finalScreen");

const startButton = document.getElementById("startButton");
const replayButton = document.getElementById("replayButton");
const pauseButton = document.getElementById("pauseButton");

const backgroundMusic = document.getElementById("backgroundMusic");
const voiceMessage = document.getElementById("voiceMessage");

const memoryPhoto = document.getElementById("memoryPhoto");
const memoryTitle = document.getElementById("memoryTitle");
const memoryText = document.getElementById("memoryText");
const photoCounter = document.getElementById("photoCounter");
const progressBar = document.getElementById("progressBar");

// ================================
// SLIDESHOW STATE
// ================================

let currentPhoto = 0;
let slideshowTimer = null;
let musicFadeTimer = null;

let isPaused = false;
let timeRemaining = PHOTO_DURATION;
let photoStartTime = 0;

// ================================
// SCREEN CONTROL
// ================================

function showScreen(screen) {
    document.querySelectorAll(".screen").forEach(function (item) {
        item.classList.remove("active");
    });

    screen.classList.add("active");
}

// ================================
// START THE EXPERIENCE
// ================================

startButton.addEventListener("click", function () {
    currentPhoto = 0;
    isPaused = false;
    timeRemaining = PHOTO_DURATION;

    pauseButton.textContent = "Pause";

    backgroundMusic.currentTime = 0;
    backgroundMusic.volume = 1;

    backgroundMusic.play().catch(function (error) {
        console.log("Background music could not play:", error);
    });

    showScreen(slideshowScreen);
    showPhoto();
});

// ================================
// DISPLAY CURRENT PHOTO
// ================================

function showPhoto() {
    const memory = memories[currentPhoto];

    memoryPhoto.src = memory.image;
    memoryPhoto.alt = memory.title;

    memoryTitle.textContent = memory.title;
    memoryText.textContent = memory.message;

    photoCounter.textContent =
        "MEMORY " + (currentPhoto + 1) + " OF " + memories.length;

    progressBar.style.width =
        ((currentPhoto + 1) / memories.length * 100) + "%";

    timeRemaining = PHOTO_DURATION;
    startPhotoTimer();
}

// ================================
// AUTOMATIC PHOTO TIMER
// ================================

function startPhotoTimer() {
    clearTimeout(slideshowTimer);

    photoStartTime = Date.now();

    slideshowTimer = setTimeout(function () {
        currentPhoto++;

        if (currentPhoto < memories.length) {
            showPhoto();
        } else {
            showVoiceScreen();
        }
    }, timeRemaining);
}

// ================================
// PAUSE / RESUME BUTTON
// ================================

pauseButton.addEventListener("click", function () {
    if (!isPaused) {
        // Pause slideshow
        clearTimeout(slideshowTimer);

        const elapsedTime = Date.now() - photoStartTime;
        timeRemaining = Math.max(0, timeRemaining - elapsedTime);

        backgroundMusic.pause();

        isPaused = true;
        pauseButton.textContent = "Resume";
    } else {
        // Resume slideshow
        isPaused = false;
        pauseButton.textContent = "Pause";

        backgroundMusic.play().catch(function (error) {
            console.log("Background music could not resume:", error);
        });

        startPhotoTimer();
    }
});

// ================================
// FADE BACKGROUND MUSIC
// ================================

function fadeMusic() {
    clearInterval(musicFadeTimer);

    const startingVolume = backgroundMusic.volume;
    const duration = 2000;
    const steps = 40;
    let step = 0;

    musicFadeTimer = setInterval(function () {
        step++;

        const progress = step / steps;

        backgroundMusic.volume =
            startingVolume +
            (QUIET_MUSIC_VOLUME - startingVolume) * progress;

        if (step >= steps) {
            clearInterval(musicFadeTimer);
            backgroundMusic.volume = QUIET_MUSIC_VOLUME;
        }
    }, duration / steps);
}

// ================================
// SHOW VOICE MESSAGE SCREEN
// ================================

function showVoiceScreen() {
    clearTimeout(slideshowTimer);
    clearInterval(musicFadeTimer);

    showScreen(voiceScreen);
    fadeMusic();

    voiceMessage.currentTime = 0;

    voiceMessage.play().catch(function (error) {
        console.log("Press play to hear the voice message:", error);
    });
}

// ================================
// AFTER VOICE MESSAGE ENDS
// ================================

voiceMessage.addEventListener("ended", function () {
    backgroundMusic.pause();
    clearInterval(musicFadeTimer);

    showScreen(finalScreen);
});

// ================================
// REPLAY EXPERIENCE
// ================================

replayButton.addEventListener("click", function () {
    clearTimeout(slideshowTimer);
    clearInterval(musicFadeTimer);

    voiceMessage.pause();
    voiceMessage.currentTime = 0;

    backgroundMusic.pause();
    backgroundMusic.currentTime = 0;
    backgroundMusic.volume = 1;

    currentPhoto = 0;
    isPaused = false;
    timeRemaining = PHOTO_DURATION;

    pauseButton.textContent = "Pause";

    showScreen(welcomeScreen);
});